<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
<style>
body {
    font-family: Arial, sans-serif;
    text-align: center;
    background-color: white;
    color: black;
    margin: 0;
    padding: 0;
}

.btn {
    padding: 8px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border-radius: 20px;
    color: white;
    background-color: #2c03b0;
    border: none;
    transition: background 0.3s ease;
}

.btn:hover {
    background-color: #1a026e;
}

legend {
    font-weight: bold;
    color: #2c03b0;
}

input[type="text"], input[type="email"] {
    background-color: transparent;
    width: 80%;
    height: 35px;
    border-radius: 8px;
    border: 1px solid #2c03b0;
    padding: 5px;
    font-size: 14px;
}

textarea {
    width: 80%;
    height: 100px;
    border-radius: 8px;
    border: 1px solid #2c03b0;
    padding: 5px;
    font-size: 14px;
}

label {
    float: left;
    position: relative;
    left: 10%;
    font-weight: bold;
    color: black;
}

/* Remove hover effect on label */
label:hover {
    color: black; /* Ensure color remains black on hover */
}

fieldset {
    background-image: rgb(196, 207, 239);
    border: none;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
}

/* New styles for the heading */
.feedback-heading {
    font-size: 30px; /* Increase font size */
    font-weight: bold; /* Make it bold */
    color: #2c03b0; /* Match the color with the theme */
    padding: 20px 0; /* Add padding for spacing */
    margin-bottom: 20px; /* Add margin below the heading */
}
</style>    
</head>

<body>
    <form action="fd.php" method="POST">
        <fieldset>
             
            <h2 class="feedback-heading">Feedback</h2>
            <label for="username">Username:</label><br>
        <input type="text" class="username" id="username" placeholder="Username" name="username"><br><br>

        <label for="email">Email:</label><br>
        <input type="text" class="email" id="email" placeholder="email" name="email"><br><br>

        <label for="message">Message:</label><br>
        <textarea placeholder="Write your message..." class="message" name="message"></textarea>
        <br><br>
        <input type="submit" value="Submit" class="btn">
        </fieldset>
        
    </form>
    <script> 
   const username = document.querySelector('.username');
const email = document.querySelector('.email');
const message = document.querySelector('.message');
const button = document.querySelector('.btn');

// Remove background color change on focus
username.addEventListener('focus', () => {
    username.style.backgroundColor = 'white';
});

email.addEventListener('focus', () => {
    email.style.backgroundColor = 'white';
});

message.addEventListener('focus', () => {
    message.style.backgroundColor = 'white';
});

// Form validation
button.addEventListener('click', (event) => {
    if (username.value == "" || email.value == "" || message.value == "") {
        alert("Form can't be empty");
        event.preventDefault();
    }
});

    </script>
</body>
</html>
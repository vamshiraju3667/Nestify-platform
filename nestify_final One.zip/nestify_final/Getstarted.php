<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Nestify</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Bree Serif", serif;
        }

        body {
            background: white;
            color: #333;
            text-align: center;
            overflow-x: hidden;
        }

        .navbar {
            background: linear-gradient(to right, #2c03b0, #030c54);
            padding: 15px;
            position: sticky;
            top: 0;
            z-index: 1000;
            animation: fadeInUp 0.8s ease-in-out;
        }

        .navbar a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease-in-out;
        }

        .navbar a:hover {
            color: #ffcc00;
        }

        .header {
            background: linear-gradient(to right, #2c03b0, #030c54);
            color: white;
            padding: 80px 20px;
            border-bottom-left-radius: 50% 100px;
            border-bottom-right-radius: 50% 100px;
            animation: fadeInDown 0.8s ease-in-out;
        }

        .header h1 {
            font-size: 3rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .content {
            background: white;
            color: black;
            padding: 50px;
            margin: 80px auto;
            width: 80%;
            border-radius: 10px;
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            text-align: left;
            animation: fadeIn 0.8s ease-in-out;
        }

        .content img {
            width: 45%;
            border-radius: 20px;
            margin-left: 20px;
            transition: transform 0.3s;
        }

        .content img:hover {
            transform: scale(1.05);
        }

        .content-text {
            flex: 1;
            padding: 20px;
        }

        .content-text p {
            margin-bottom: 20px;
            line-height: 1.8;
            font-size: 1.1rem;
        }

        .feature-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 40px;
        }

        .feature-card {
            background: #f1f1ff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(44, 3, 176, 0.2);
            text-align: left;
        }

        .feature-card h3 {
            color: #2c03b0;
            margin-bottom: 10px;
        }

        .advantages {
            background:rgb(255, 255, 255);
            padding: 60px;
            margin: 40px auto;
            width: 70%;
            border-radius: 20px;
            animation: fadeIn 0.8s ease-in-out;
        }

        .advantages h2 {
            margin-bottom: 50px;
            color:rgba(43, 3, 176, 0.78);
        }

        .advantages ul {
            list-style-type: none;
            padding: 0;
            text-align: left;
        }

        .advantages li {
            margin: 10px 0;
            padding-left: 20px;
            position: relative;
        }

        .advantages li:before {
            content: '✔️';
            position: absolute;
            left: 0;
            color: #2c03b0;
        }

        .carousel-container {
            overflow: hidden;
            position: relative;
            width: 60%;
            margin: 30px auto;
            animation: fadeIn 0.3s ease-in-out;
            border-radius: 20px;
        }

        .carousel {
            display: flex;
            width: 200%;
            animation: scroll 15s linear infinite;
        }

        .carousel img {
            width: 20%;
            border-radius: 10px;
            transition: transform 0.4s;
            margin: 0 10px;
        }

        @keyframes scroll {
            0% {
                transform: translateX(0%);
            }
            100% {
                transform: translateX(-100%);
            }
        }



        .get-started {
            background: linear-gradient(to right, #2c03b0, #030c54);
            color: white;
            padding: 20px 30px;
            border-radius: 35px;
            font-size: 1.5rem;
            display: inline-block;
            margin-top: 50px;
            cursor: pointer;
            transition: background 0.2s ease, transform 0.1s ease;
            position: relative;
            overflow: hidden;
            text-decoration: none;
            animation: fadeInUp 0.6s ease-in-out;
        }

        .get-started:hover {
            transform: scale(1.1);
            background: linear-gradient(to right, #2c03b0, #030c54);
        }

        .footer {
            background:rgba(52, 10, 190, 0.86);
            color: white;
            padding: 20px;
            width: 100%;
            margin-top: 50px;
            animation: fadeInUp 1s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Welcome to Nestify</h1>
    </div>

    <div class="content">
        <div class="content-text">
            <p>🏡 Buy Sell Rent Properties – Direct, Transparent & Commission-Free platform</p>
            <p>Welcome to our modern real estate platform built to simplify the way people buy, sell, or rent properties — with zero broker involvement</p>
            <p>Whether you're searching for your perfect home or selling a property, we help you connect directly with the right people — saving time and money</p>
        </div>
        <img src="https://assets.onecompiler.app/438ujdw86/43e8p4svr/Screenshot%202025-04-08%20233252.png" alt="Rental Home">
    </div>

    <div class="advantages">
        <h2>💼 Key Features</h2>
        <ul>
            <li>🚫 No Brokers, No Commission – Deal directly with property owners.</li>
            <li>🔍 Verified Listings – Ensuring trust and transparency.</li>
            <li>🔐 Secure Platform – Your data is protected.</li>
            <li>⚡ Easy Search Filters – Find exactly what you need, fast.</li>
            <li>📞 Direct Communication – Chat directly with buyers or sellers.</li>
            <li>🚀 Fast & Reliable – Post or find properties in minutes.</li>
        </ul>

        <h2 style="margin-top: 60px;">🌟 What You Can Buy & Sell or even Rent!</h2>
        <ul>
            <li>🏞 Lands – Residential, Commercial & Agricultural</li>
            <li>🏢 Flats & Apartments – All size units in prime locations</li>
            <li>🏘 Villas & Duplexes – Premium independent homes</li>
            <li>👦 Boys' Hostels – Secure, well-connected student accommodations</li>
            <li>👧 Girls' Hostels – Safe, convenient living for female students</li>
            <li>🏠 Others – Shops, offices, studios, etc.</li>
        </ul>
    </div>

    <div class="carousel-container">
        <div class="carousel">
            <img src="https://assets.onecompiler.app/438ujdw86/43e8nqc72/villa%203bhk.jpeg" alt="House 1">
            <img src="https://assets.onecompiler.app/438ujdw86/3x8qtrfgp/A%20New%20Build%20Conversation%20about%20Exterior%20Stone%20(It's%20all%20in%20the%20Undertones).jpeg" alt="House 2">
            <img src="https://assets.onecompiler.app/438ujdw86/43e8nqc72/villa%204bhk.jpeg" alt="House 3">
            <img src="https://assets.onecompiler.app/438ujdw86/438ujeapw/849db02a-ccd1-40f9-8fd1-e272b7f4404c.jpg" alt="House 4">
            <img src="https://assets.onecompiler.app/438ujdw86/43bkzbuv9/Alma%20Homes%20on%20Instagram_%20_You%E2%80%99re%20building%20a%20home%E2%80%A6.jpeg" alt="House 5">
            <img src="https://assets.onecompiler.app/438ujdw86/3x8qtrfgp/Realistic%203D%20Designs_%20Elevate%20Your%20Modern%20Interiors%20&%20Exteriors%20(1).jpeg" alt="House 6">
            <img src="https://assets.onecompiler.app/438ujdw86/3x8qtrfgp/Innovative%20Living_%20Exploring%20the%20Charms%20of%20a%204%20BHK%20Flat%20Roof%20Home.jpeg" alt="House 7">
            <img src="https://assets.onecompiler.app/438ujdw86/3x8qtrfgp/A%20New%20Build%20Conversation%20about%20Exterior%20Stone%20(It's%20all%20in%20the%20Undertones).jpeg" alt="House 8">
        </div>
    </div>

    <a href="register.php" class="get-started">Get Started</a>

    <div class="footer">
        <p>&copy; 2025 Nestify. All Rights Reserved.</p>
    </div>
</body>
</html>

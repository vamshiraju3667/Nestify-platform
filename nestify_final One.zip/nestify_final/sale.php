<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listing a Home - Nestify</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f9fc;
            color: #333;
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color:rgb(34, 46, 136);
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        main {
            flex: 1;
            text-align: center;
            padding: 50px 20px;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            text-align: left;
        }

        label {
            display: block;
            margin: 10px 0 5px;
        }

        input[type="text"],
        input[type="tel"],
        textarea {
            width: 100%;
            padding: 8px;
            margin: 5px 0 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #283593;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #1a237e;
        }

        footer {
            background-color: #283593;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>NESTIFY</h1>
    </header>
    
    <main>
        <h2>Enter details to Rent a House</h2>
        <form name="listingForm" method="post" action="listing.php" enctype="multipart/form-data">
            <label for="image">Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required>

            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required>

            <label for="city">District:</label>
            <input type="text" id="city" name="city" required>

            <label for="type">Categories</label>
            <select id="type" name="type" required>
                <option value="1">1 - Regular</option>
                <option value="2">2 - Bachelors</option>
                <option value="3">3 - Hostel(Girls)</option>
                <option value="4">4 - Hostel(Boys)</option>
            </select>

            <label for="phone">Phone:</label>
            <input type="tel" id="phone" name="phone" required>

            <label for="price">Price (₹):</label>
            <input type="tel" id="price" name="price" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" required></textarea>

            <button type="submit" id="submitButton">Submit</button>
        </form>

        <div id="message" style="margin-top: 10px; color: red;"></div>
    </main>

    <footer>
        <p>&copy; 2025 Nestify. All rights reserved.</p>
    </footer>

    <script>
       document.querySelector("form[name='listingForm']").addEventListener("submit", function (e) {
            let image = document.getElementById("image").files.length;
            let phone = document.getElementById("phone").value;
            let price = document.getElementById("price").value;

            if (image === 0 || !phone || !price) {
                e.preventDefault(); // Stop form submission
                document.getElementById("message").innerText = "Please fill all required fields!";
            }
        });
    </script>
</body>
</html>

<?php
require_once 'dbConnect.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $address = $_POST['address'];
    $city = $_POST['district'];  // corrected to match form name
    $type = $_POST['type'];
    $phone = $_POST['phone'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    if (!empty($_FILES["image"]["name"])) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFilePath = $targetDir . $fileName;
        $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
        $allowTypes = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($fileType, $allowTypes)) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
                try {
                    $sql = "INSERT INTO listing2 (image, address, city, type, phone, price, description) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$fileName, $address, $city, $type, $phone, $price, $description]);

                    echo "<script>alert('Property listed successfully!'); window.location.href='property.html';</script>";
                } catch (PDOException $e) {
                    echo "<script>alert('Database error: " . $e->getMessage() . "');</script>";
                }
            } else {
                echo "<script>alert('Failed to upload image!');</script>";
            }
        } else {
            echo "<script>alert('Only JPG, JPEG, PNG & GIF files are allowed!');</script>";
        }
    } else {
        echo "<script>alert('Please select an image!');</script>";
    }
}
?>

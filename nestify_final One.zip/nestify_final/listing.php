<?php
require_once 'dbConnect.php'; // Include the database connection

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $address = $_POST['address'];
    $city = $_POST['city'];
    $type = $_POST['type'];
    $phone = $_POST['phone'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    // Handle file upload
    if (!empty($_FILES["image"]["name"])) {
        $targetDir = "uploads/"; // Ensure this folder exists and has write permissions
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true); // Create directory if not exists
        }

        $fileName = time() . "_" . basename($_FILES["image"]["name"]); // Unique file name
        $targetFilePath = $targetDir . $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

        // Allowed file types
        $allowTypes = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($fileType, $allowTypes)) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
                try {
                    // Insert into database
                    $sql = "INSERT INTO listings (image, address, city, type, phone, price, description) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $pdo->prepare($sql);
                    if ($stmt->execute([$fileName, $address, $city, $type, $phone, $price, $description])) {
                        echo "<script>window.location.href='home.php';</script>"; // Redirect to success page
                    } else {
                        echo "<script>document.getElementById('message').innerText = 'Database error!';</script>";
                    }
                } catch (PDOException $e) {
                    echo "<script>document.getElementById('message').innerText = 'Database error: " . $e->getMessage() . "';</script>";
                }
            } else {
                echo "<script>document.getElementById('message').innerText = 'File upload failed!';</script>";
            }
        } else {
            echo "<script>document.getElementById('message').innerText = 'Invalid file type!';</script>";
        }
    } else {
        echo "<script>document.getElementById('message').innerText = 'Please select an image!';</script>";
    }
}
?>

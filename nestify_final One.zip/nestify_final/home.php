<?php
session_start();
if(isset($_SESSION['user'])){
    $user = $_SESSION['user'];

}else{
    header("Location: index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Nestify Interface</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700;900&display=swap" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #ffffff;
      color: #222;
    }

    header {
      background-color:rgba(15, 23, 116, 0.95);
      color: #fff;
      padding: 40px 20px;
      text-align: center;
      font-size: 3.5em;
      font-weight: 900;
      letter-spacing: 2px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    nav {
      background-color:rgba(11, 24, 117, 0.95);
      padding: 16px 0;
    }

    nav ul {
      list-style: none;
      text-align: center;
      margin: 0;
      padding: 0;
    }

    nav ul li {
      display: inline-block;
      margin: 0 25px;
    }

    nav ul li a {
      text-decoration: none;
      color: #fff;
      font-weight: 500;
      font-size: 1.1em;
      transition: color 0.3s ease;
    }

    nav ul li a:hover {
      color: #c5cae9;
    }

    .hero {
      background: linear-gradient(to right,rgba(9, 4, 143, 0.98),rgba(3, 12, 84, 0.95));
      color: white;
      text-align: center;
      padding: 75px 40px;
    }

    .hero h2 {
      font-size: 2.4em;
      margin-bottom: 20px;
      animation: fadeInDown 1s ease-in-out;
    }

    .hero p {
      font-size: 1.2em;
      max-width: 720px;
      margin: 0 auto;
      animation: fadeInUp 1.2s ease-in-out;
    }

    footer {
      background-color: #1a237e;
      color: #fff;
      text-align: center;
      padding: 8px 8px;
      margin-top: 60px;
      font-size: 0.95em;
    }

    footer p {
      margin: 6px 0;
    }

    @keyframes fadeInDown {
      0% { opacity: 0; transform: translateY(-30px); }
      100% { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeInUp {
      0% { opacity: 0; transform: translateY(30px); }
      100% { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 768px) {
      nav ul li {
        margin: 0 10px;
      }

      .hero h2 {
        font-size: 2em;
      }

      .hero p {
        font-size: 1em;
      }
    }
  </style>
</head>
<body>

<header>NESTIFY</header>

<nav>
  <ul>
    <li><a href="Getstarted.php">Home</a></li>
    <li><a href="property.html">Propertyconnect</a></li>
    <li><a href="about.html">About Us</a></li>
    <li><a href="logout.php">Log out</a></li>
  </ul>
</nav>

<section class="hero">
  <h2>Buy & Rent Your House Without a Broker</h2>
  <p>Welcome to NESTIFY – where tenants and owners connect directly for a seamless rental experience.</p>
</section>

<section class="py-20 bg-white px-4">
  <div class="flex flex-col items-center gap-12 max-w-7xl mx-auto">
    <div class="flex flex-col md:flex-row gap-12 w-full justify-center">
      <!-- List Your House Card -->
      <div class="w-full md:w-[44%] bg-white border border-indigo-100 shadow-xl rounded-3xl p-8 text-center transform transition hover:-translate-y-1 hover:shadow-2xl">
        <div class="flex justify-center mb-4">
          <div class="bg-indigo-100 text-indigo-700 p-4 rounded-full text-3xl shadow-sm">📍</div>
        </div>
        <h4 class="text-2xl font-extrabold text-indigo-800 mb-3">List Your House</h4>
        <p class="text-gray-600 mb-6 text-sm leading-relaxed">
        Post your property with pictures and details. Fast and simple without any effort.
        </p>
        <a href="sale.php" class="inline-block bg-indigo-600 hover:bg-indigo-700 text-white text-base font-semibold px-6 py-2 rounded-full transition duration-300 shadow-md">
          🚀 Upload Details
        </a>
      </div>

      <!-- Find a House Card -->
      <div class="w-full md:w-[44%] bg-white border border-indigo-100 shadow-xl rounded-3xl p-8 text-center transform transition hover:-translate-y-1 hover:shadow-2xl">
        <div class="flex justify-center mb-4">
          <div class="bg-indigo-100 text-indigo-700 p-4 rounded-full text-3xl shadow-sm">🔍</div>
        </div>
        <h4 class="text-2xl font-extrabold text-indigo-800 mb-3">Find Rent House</h4>
        <p class="text-gray-600 mb-6 text-sm leading-relaxed">
        Explore various house in your preferred locations without a middlemen. 
        </p>
        <a href="buy.php" class="inline-block bg-indigo-600 hover:bg-indigo-700 text-white text-base font-semibold px-6 py-2 rounded-full transition duration-300 shadow-md">
          🔎 Search a house
        </a>
      </div>
    </div>

    <!-- Feedback Card -->
    <div class="w-full max-w-lg bg-white border border-indigo-100 shadow-xl rounded-3xl p-8 text-center transform transition hover:-translate-y-1 hover:shadow-2xl">
      <div class="flex justify-center mb-4">
        <div class="bg-indigo-100 text-indigo-700 p-4 rounded-full text-3xl shadow-sm">💬</div>
      </div>
      <h4 class="text-2xl font-extrabold text-indigo-800 mb-3">Feedback</h4>
      <p class="text-gray-600 mb-6 text-sm leading-relaxed">
        Help us grow! 💡 Share your thoughts or suggestions to make Nestify even better.
      </p>
      <a href="feedback.php" class="inline-block bg-indigo-600 hover:bg-indigo-700 text-white text-base font-semibold px-6 py-2 rounded-full transition duration-300 shadow-md">
        ✍️ Submit Feedback
      </a>
    </div>
  </div>
</section>

<footer>
  <p>&copy; 2025 Nestify. All rights reserved.</p>
  <p>Mahabubnagar, Telangana</p>
  <p>Email: info@nestify.com | Phone: (123) 456-7890</p>
</footer>

</body>
</html>

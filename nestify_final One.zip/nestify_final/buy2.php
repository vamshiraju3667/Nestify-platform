<?php
require_once 'dbConnect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['property_id'])) {
    $propertyId = intval($_POST['property_id']);
    $stmt = $pdo->prepare("DELETE FROM listing2 WHERE id = ?");
    $stmt->execute([$propertyId]);
    $_SESSION['success'] = "🎉 Property bought successfully!";
    header("Location: buy2.php");
    exit();
}

$stmt = $pdo->query("SELECT * FROM listing2 ORDER BY created_at DESC");
$properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Find Properties | PropertyConnect</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/alpinejs" defer></script>
  <style>
    body { font-family: 'Inter', sans-serif; }
    html, body {
      height: 100%;
    }
  </style>
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen">

  <!-- Header -->
  <header class="bg-white shadow-md sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
      <h1 class="text-2xl font-bold text-indigo-600">🏡 PropertyConnect</h1>
      <nav class="space-x-4 text-sm font-medium">
        <a href="property.html" class="hover:text-cyan-500 transition">Back</a>
      </nav>
    </div>
  </header>

  <!-- Main Section -->
  <main class="flex-grow">
    <section class="py-16 px-6" id="browse">
      <div class="max-w-6xl mx-auto">
        <h2 class="text-3xl font-bold text-cyan-700 mb-8 text-center">🔍 Browse Available Properties</h2>

        <?php if (isset($_SESSION['success'])): ?>
          <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6 max-w-xl mx-auto text-center">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
          </div>
        <?php endif; ?>

        <div class="grid md:grid-cols-3 gap-6">
          <?php if (count($properties) > 0): ?>
            <?php foreach ($properties as $property): ?>
              <div x-data="{ showModal: false }" class="bg-white border border-gray-200 shadow-md rounded-xl overflow-hidden hover:shadow-lg transition relative">
                <!-- Image -->
                <img src="uploads/<?php echo htmlspecialchars($property['image']); ?>" alt="Property Image" class="w-full h-60 object-cover">

                <!-- Content -->
                <div class="p-4 space-y-1 text-sm">
                  <h3 class="text-lg font-bold text-indigo-600">🏠 <?php echo htmlspecialchars($property['type']); ?> in <?php echo htmlspecialchars($property['city']); ?></h3>
                  <p class="text-gray-600">Location: <?php echo htmlspecialchars($property['address']); ?></p>
                  <p class="text-gray-600">Type: <?php echo htmlspecialchars($property['type']); ?></p>
                  <p class="text-gray-600">Price: ₹<?php echo htmlspecialchars($property['price']); ?></p>
                  <p class="text-gray-500 text-sm"><?php echo htmlspecialchars($property['description']); ?></p>

                  <div class="flex justify-center mt-3">
                    <button @click="showModal = true"
                      class="bg-indigo-600 text-white px-6 py-2 rounded-full hover:bg-indigo-700 transition font-medium shadow">
                       Buy
                    </button>
                  </div>
                </div>

                <!-- Modal -->
                <div
                  x-show="showModal"
                  x-cloak
                  class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50"
                  style="display: none;">
                  <div class="bg-white rounded-xl shadow-lg p-6 w-full max-w-lg mx-auto border border-gray-300">
                    <h2 class="text-2xl font-semibold text-indigo-700 mb-4">Confirm Buy</h2>
                    <p class="text-gray-700 mb-4 font-medium">
                      Would you like to proceed with buying this house? Contact below phone number.
                    </p>

                    <div class="bg-gray-100 p-4 rounded mb-4 text-sm text-gray-800">
                      <p><strong>📞 Phone:</strong> <?php echo htmlspecialchars($property['phone']); ?></p>
                      <p><strong>🏷️ Category:</strong> <?php echo htmlspecialchars($property['type']); ?></p>
                      <p><strong>📝 Description:</strong> <?php echo htmlspecialchars($property['description']); ?></p>
                    </div>

                    <div class="flex justify-end space-x-4 mt-4">
                      <form method="POST">
                        <input type="hidden" name="property_id" value="<?php echo $property['id']; ?>">
                        <button type="submit"
                          class="bg-blue-500 text-white px-5 py-2 rounded hover:bg-blue-800 transition font-medium">
                          Yes, Buy
                        </button>
                      </form>
                      <button @click="showModal = false"
                        class="bg-gray-300 px-5 py-2 rounded hover:bg-gray-400 transition font-medium">
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
                <!-- End Modal -->
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="text-center text-gray-600 col-span-3">No properties found.</p>
          <?php endif; ?>
        </div>
      </div>
    </section>
  </main>

  <!-- Footer -->
  <footer class="bg-gradient-to-r from-indigo-600 to-cyan-500 text-white py-6 text-center mt-auto">
    <p class="text-lg font-medium">© 2025 PropertyConnect. Find Homes You’ll Love.</p>
  </footer>
</body>
</html>

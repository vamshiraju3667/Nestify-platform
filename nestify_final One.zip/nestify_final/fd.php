<?php
require_once 'dbConnect.php'; // Include the database connection

session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get input values safely
    $username = isset($_POST["username"]) ? trim($_POST["username"]) : null;
    $email = isset($_POST["email"]) ? trim($_POST["email"]) : null;
    $message = isset($_POST["message"]) ? trim($_POST["message"]) : null;

    // Validate input
    if (!$username || !$email || !$message) {
        die("All fields (Username, Email, Message) are required.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    try {
        // Use prepared statement to prevent SQL injection
        $stmt = $pdo->prepare("INSERT INTO  feedback (username, email, message) VALUES (:username, :email, :message)");
        $stmt->execute([
            ':username' => $username,
            ':email' => $email,
            ':message' => $message
        ]);

        echo "Feedback submitted successfully!";
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>

<?php
require_once 'dbConnect.php';
session_start();

if (isset($_POST['rent_id'])) {
    $rent_id = $_POST['rent_id'];

    $stmt = $pdo->prepare("SELECT image FROM listings WHERE id = ?");
    $stmt->execute([$rent_id]);
    $listing = $stmt->fetch();

    if ($listing) {
        $imagePath = "uploads/" . $listing['image'];
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }

    $stmt = $pdo->prepare("DELETE FROM listings WHERE id = ?");
    $stmt->execute([$rent_id]);

    echo "success";
    exit;
}

$sql = "SELECT * FROM listings ORDER BY id DESC";
$stmt = $pdo->query($sql);
$listings = $stmt->fetchAll();

$category_names = [
    1 => "Regular",
    2 => "Bachelors",
    3 => "Hostel (Girls)",
    4 => "Hostel (Boys)"
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Buy House - Nestify</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* General styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f6f8;
        }

        header {
            background-color: rgb(15, 23, 116);
            color: white;
            padding: 20px;
            text-align: center;
        }

        .main {
            padding: 40px 20px;
            max-width: 1200px;
            margin: auto;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .cards-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }

        .card {
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            transition: transform 0.2s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-image img {
            width: 100%;
            height: 240px;
            object-fit: cover;
        }

        .no-image {
            height: 200px;
            background-color: #ddd;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #555;
        }

        .card-details {
            padding: 26px;
        }

        .card-details h3 {
            margin: 0 0 10px;
            color: #283593;
        }

        .card-details p {
            margin: 5px 0;
            font-size: 14px;
            color: #444;
        }

        .rent-btn {
            background-color:rgb(16, 6, 149);
            color: white;
            padding: 10px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            transition: background-color 0.2s ease;
        }

        .rent-btn:hover {
            background-color: #283593;
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(3px);
        }

        .modal-content {
            background: #fff;
            border-radius: 10px;
            padding: 30px;
            width: 90%;
            max-width: 420px;
            margin: 10% auto;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.3s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.9); }
            to { opacity: 1; transform: scale(1); }
        }

        .modal-content h3 {
            margin-top: 0;
            color: #283593;
            font-size: 20px;
        }

        .modal-content p {
            margin: 10px 0;
            font-size: 15px;
            color: #333;
            font-weight: 500;
        }

        .modal-content span {
            font-weight: bold;
            color: #000;
        }

        .modal-buttons {
            margin-top: 20px;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .modal-buttons button {
            padding: 10px 16px;
            border-radius: 6px;
            border: none;
            font-weight: bold;
            cursor: pointer;
        }

        .confirm {
            background:rgb(23, 36, 133);
            color: #fff;
        }

        .confirm:hover {
            background:rgb(13, 28, 142);
        }

        .cancel {
            background: #ddd;
            color: #333;
        }

        .cancel:hover {
            background: #ccc;
        }
    </style>
</head>
<body>

<header>
    <h1>Nestify</h1>
</header>

<div class="main">
    <h2>Available House List</h2>

    <?php if (count($listings) > 0): ?>
        <div class="cards-container">
            <?php foreach ($listings as $listing): ?>
                <div class="card" id="row-<?= htmlspecialchars($listing['id']) ?>">
                    <div class="card-image">
                        <?php if (!empty($listing['image'])): ?>
                            <img src="uploads/<?= htmlspecialchars($listing['image']) ?>" alt="Property Image">
                        <?php else: ?>
                            <div class="no-image">No Image</div>
                        <?php endif; ?>
                    </div>
                    <div class="card-details">
                        <h3><?= htmlspecialchars($listing['address']) ?></h3>
                        <p><strong>District:</strong> <?= htmlspecialchars($listing['city']) ?></p>
                        <p><strong>Category:</strong> <?= $category_names[$listing['type']] ?? "Unknown" ?></p>
                        <p><strong>Price:</strong> ₹<?= htmlspecialchars($listing['price']) ?></p>
                        <p><strong>Description:</strong> <?= htmlspecialchars($listing['description']) ?></p>
                        <button class="rent-btn" onclick="confirmRent(
                            <?= htmlspecialchars($listing['id']) ?>,
                            '<?= htmlspecialchars($listing['phone']) ?>',
                            '₹<?= htmlspecialchars($listing['price']) ?>',
                            `<?= htmlspecialchars($listing['description']) ?>`
                        )">Rent</button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No listings available.</p>
    <?php endif; ?>
</div>

<!-- Modal -->
<div id="rentModal" class="modal">
    <div class="modal-content">
        <h3>Confirm Rent</h3>
        <p>Would you like to proceed with renting this house?
            Contact below phone number.
        </p>
        <p><strong>Phone Number:</strong> <span id="modalPhone"></span></p>
        <p><strong>Price:</strong> <span id="modalPrice"></span></p>
        <p><strong>Description:</strong> <span id="modalDescription"></span></p>
        <div class="modal-buttons">
            <button class="confirm" onclick="rentHouse()">Yes, Rent</button>
            <button class="cancel" onclick="closeModal()">Cancel</button>
        </div>
    </div>
</div>

<script>
    let selectedHouseId = null;

    function confirmRent(id, phone, price, description) {
        selectedHouseId = id;
        document.getElementById('modalPhone').textContent = phone;
        document.getElementById('modalPrice').textContent = price;
        document.getElementById('modalDescription').textContent = description;
        document.getElementById('rentModal').style.display = 'block';
    }

    function closeModal() {
        document.getElementById('rentModal').style.display = 'none';
    }

    function rentHouse() {
        if (selectedHouseId) {
            fetch('buy.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'rent_id=' + selectedHouseId
            })
            .then(response => response.text())
            .then(data => {
                if (data === "success") {
                    document.getElementById('row-' + selectedHouseId).remove();
                    closeModal();
                } else {
                    alert("Error renting house!");
                }
            })
            .catch(error => console.error('Error:', error));
        }
    }

    window.onclick = function(event) {
        const modal = document.getElementById('rentModal');
        if (event.target === modal) {
            closeModal();
        }
    }
</script>

</body>
</html>
